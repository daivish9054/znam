export { Thumbnail as default } from "./thumbnail"
