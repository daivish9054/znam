import { useExtensionBaseProps } from "../../../hooks/use-extension-base-props"

export const useSettingContainerProps = () => {
  const baseProps = useExtensionBaseProps()

  return baseProps
}
