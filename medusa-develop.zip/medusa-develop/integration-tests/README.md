# Integration-tests

Check out the [local development documentation to learn how to run integration tests](https://docs.medusajs.com/usage/local-development#run-tests-in-the-repository).
