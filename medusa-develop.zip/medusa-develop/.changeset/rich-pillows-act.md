---
"@medusajs/oas-github-ci": patch
---

feat(@medusajs/oas-github-ci): changed output path to match new docs workspace
