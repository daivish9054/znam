---
"@medusajs/medusa": patch
"@medusajs/workflows": patch
---

fix(medusa, workflows): Create product workflow with Isolated modules + module registration
