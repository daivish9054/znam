---
"@medusajs/utils": patch
---

feat(utils): Provide an utils that allows to convert an array of fields to a complete remote query object
